function [BestHistory, BestValue, BestPosition, GNBG, AcceptanceReachPoint, Extra] = ...
         runAlgorithmTemplate(GNBG, params)
%RUNALGORITHMTEMPLATE  GNBG-III compatible algorithm template (DE example)
%
%   This function is called by GNBG_III_CompetitionHarness.m.
%   It implements a reference DE/rand/1/bin algorithm and returns:
%
%   INPUT:
%       GNBG   - benchmark struct loaded from F*_*.mat, including:
%                  GNBG.Dimension
%                  GNBG.MaxEvals
%                  GNBG.MinCoordinate
%                  GNBG.MaxCoordinate
%                  GNBG.OptimumValue
%       params - struct with algorithm hyperparameters, e.g.:
%                  params.PopulationSize
%                  params.F
%                  params.Cr
%
%   OUTPUT:
%       BestHistory          - 1 x MaxEvals vector of best-so-far f(x) per FE
%       BestValue            - final best objective value
%       BestPosition         - final best solution vector
%       GNBG                 - updated benchmark struct
%       AcceptanceReachPoint - FE at which |f_best - f*| <= 1e-8 (Inf if never)
%       Extra                - struct with optional diagnostics:
%                                Extra.DiversityHistory  (1 x 50)
%                                Extra.ImprovementCount
%                                Extra.StagnationPeriods
%
%   PARTICIPANTS:
%       - KEEP the function interface.
%       - You may replace the internal DE logic with your algorithm
%         (marked clearly below).
%       - Always use [f, GNBG] = fitness(X, GNBG) for evaluations.
%       - Respect GNBG.MaxEvals (do not exceed the evaluation budget).

    %--------------------------------------------------------------
    %  1. Extract basic information / hyperparameters
    %--------------------------------------------------------------
    D        = GNBG.Dimension;
    MaxEvals = GNBG.MaxEvals;
    
    % Lower and upper bounds (allow scalar or 1xD)
    LB = GNBG.MinCoordinate;
    UB = GNBG.MaxCoordinate;
    if isscalar(LB), LB = LB * ones(1, D); end
    if isscalar(UB), UB = UB * ones(1, D); end
    
    % Algorithm hyperparameters with sensible defaults
    if isfield(params, 'PopulationSize')
        NP = params.PopulationSize;
    else
        NP = 100;
    end
    if isfield(params, 'F')
        F = params.F;
    else
        F = 0.5;
    end
    if isfield(params, 'Cr')
        Cr = params.Cr;
    else
        Cr = 0.9;
    end
    
    %--------------------------------------------------------------
    %  2. Initialise population
    %--------------------------------------------------------------
    % X: NP x D population matrix
    X = LB + (UB - LB) .* rand(NP, D);
    
    % Best-history buffer: best-so-far value at each FE (1..MaxEvals)
    BestHistory = inf(1, MaxEvals);
    
    % Diversity sampling schedule (50 points over [1, MaxEvals])
    divSampleFEs = round(linspace(1, MaxEvals, 50));
    divIndex      = 1;
    DiversityHistory = NaN(1, 50);
    
    % Improvement / stagnation counters
    ImprovementCount  = 0;
    StagnationCount   = 0;
    currentStagnation = 0;
    
    % Ensure GNBG.FE is initialised
    if ~isfield(GNBG, 'FE') || isempty(GNBG.FE)
        GNBG.FE = 0;
    end
    prevFE = GNBG.FE;
    
    % Initial evaluation
    [fitVals, GNBG] = fitness(X, GNBG);   % increments GNBG.FE by NP
    [BestValue, bestID] = min(fitVals);
    BestPosition        = X(bestID, :);
    
    % Fill BestHistory for these initial evaluations
    newFE = GNBG.FE;
    BestHistory(prevFE+1:newFE) = BestValue;
    prevFE = newFE;
    
    lastBest = BestValue;   % for relative improvement tracking
    
    %--------------------------------------------------------------
    %  3. Main optimisation loop
    %--------------------------------------------------------------
    while GNBG.FE < MaxEvals
        
        %==========================================================
        %  BEGIN: REPLACE THIS BLOCK WITH YOUR OWN ALGORITHM
        %==========================================================
        
        %------------------------------
        % 3.1 Mutation: DE/rand/1
        %------------------------------
        R = NaN(NP, 3);
        for i = 1:NP
            idx = randperm(NP);
            idx(idx == i) = [];     % exclude self
            R(i, :) = idx(1:3);
        end
        
        V = X(R(:,1), :) + F .* (X(R(:,2), :) - X(R(:,3), :));  % donor vectors
        
        %------------------------------
        % 3.2 Crossover: binomial
        %------------------------------
        U = X;  % trial vectors start as copy of X
        
        % Ensure at least one dimension is taken from donor
        K = sub2ind([NP, D], (1:NP)', randi(D, [NP,1]));
        U(K) = V(K);
        
        % Apply binomial crossover mask
        crossMask = rand(NP, D) < Cr;
        U(crossMask) = V(crossMask);
        
        %------------------------------
        % 3.3 Boundary handling (clipping)
        %------------------------------
        % Implicit expansion (R2016b+) is assumed here. If you need to support
        % older MATLAB, replace with bsxfun or repmat.
        U = max(min(U, UB), LB);
        
        %------------------------------
        % 3.4 Evaluate offspring
        %------------------------------
        oldFE = GNBG.FE;
        [fitOff, GNBG] = fitness(U, GNBG);   % increments FE by #offspring
        newFE = GNBG.FE;
        
        %------------------------------
        % 3.5 Selection
        %------------------------------
        better = fitOff < fitVals;
        X(better, :)   = U(better, :);
        fitVals(better) = fitOff(better);
        
        %------------------------------
        % 3.6 Update global best
        %------------------------------
        [currBest, currID] = min(fitVals);
        if currBest < BestValue
            BestValue    = currBest;
            BestPosition = X(currID, :);
        end
        
        %------------------------------
        % 3.7 Update BestHistory for each FE consumed
        %------------------------------
        BestHistory(oldFE+1:newFE) = BestValue;
        prevFE = newFE;
        
        %------------------------------
        % 3.8 Improvement & stagnation tracking
        %------------------------------
        if lastBest ~= 0
            relImprovement = (lastBest - BestValue) / abs(lastBest);
        else
            relImprovement = 0;
        end
        
        if relImprovement > 0.01   % >1% improvement
            ImprovementCount  = ImprovementCount + 1;
            lastBest          = BestValue;
            currentStagnation = 0;
        else
            currentStagnation = currentStagnation + 1;
        end
        
        if currentStagnation > 100
            StagnationCount   = StagnationCount + 1;
            currentStagnation = 0;
        end
        
        %------------------------------
        % 3.9 Diversity snapshots (50 points)
        %------------------------------
        while divIndex <= numel(divSampleFEs) && GNBG.FE >= divSampleFEs(divIndex)
            % mean pairwise distance among individuals
            DiversityHistory(divIndex) = mean(pdist(X));
            divIndex = divIndex + 1;
        end
        
        % Optional early stopping if extremely close to optimum
        if isfield(GNBG, 'OptimumValue')
            if abs(BestValue - GNBG.OptimumValue) <= 1e-12
                % Fill remaining BestHistory entries and terminate
                if newFE < MaxEvals
                    BestHistory(newFE+1:MaxEvals) = BestValue;
                end
                GNBG.FE = MaxEvals;
                break;
            end
        end
        
        %==========================================================
        %  END: YOUR ALGORITHM BLOCK
        %==========================================================
        
        % Safety break (should normally be controlled by fitness/MaxEvals)
        if GNBG.FE >= MaxEvals
            break;
        end
    end

    %--------------------------------------------------------------
    %  4. Finalise BestHistory and compute AcceptanceReachPoint
    %--------------------------------------------------------------
    % Fill any remaining uninitialised entries with final BestValue
    lastFilled = find(isfinite(BestHistory) & BestHistory < inf, 1, 'last');
    if isempty(lastFilled)
        BestHistory(:) = BestValue;
    elseif lastFilled < MaxEvals
        BestHistory(lastFilled+1:MaxEvals) = BestValue;
    end
    
    % Compute FE at which |f_best - f*| <= 1e-8
    AcceptanceReachPoint = Inf;
    if isfield(GNBG, 'OptimumValue')
        err = abs(BestHistory - GNBG.OptimumValue);
        idx = find(err <= 1e-8, 1, 'first');
        if ~isempty(idx)
            AcceptanceReachPoint = idx;  % FE index
        end
    end
    
    %--------------------------------------------------------------
    %  5. Extra diagnostics
    %--------------------------------------------------------------
    Extra = struct();
    Extra.DiversityHistory  = DiversityHistory;
    Extra.ImprovementCount  = ImprovementCount;
    Extra.StagnationPeriods = StagnationCount;
end
