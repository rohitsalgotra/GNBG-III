%==========================================================================
% GNBG-III Competition Harness
%==========================================================================
% This script:
%   - Runs a user-supplied algorithm on all GNBG-III benchmarks
%   - Computes:
%       * Error at fixed evaluation budgets
%       * Multi-target FE-to-target for thresholds {1e-1, 1e-3, 1e-5, 1e-8}
%       * Expected Running Time (ERT) per target
%       * Basic success statistics for |f - f*| <= 1e-8
%   - Exports:
%       * GNBG_III_DetailedResults_<AlgorithmName>.mat
%       * GNBG_III_Detailed_Results_<AlgorithmName>.csv
%
% PARTICIPANTS:
%   1. Implement your algorithm in a function with signature:
%
%      [BestHistory, BestValue, BestPosition, GNBG, AcceptanceReachPoint] = ...
%          runAlgorithmTemplate(GNBG, params)
%
%      (Optionally you may return a 6th output "Extra" with custom metrics.)
%
%   2. Set AlgorithmName and AlgorithmHandle below.
%   3. Run this script. Submit the .mat and .csv files.
%==========================================================================

close all; clear; clc;

%% ==================== CONFIGURATION ====================

% Directory with GNBG-III benchmark .mat files
benchmarkDir = 'GNBG_III_Benchmarks';

% Algorithm name (used in output filenames)
AlgorithmName   = 'DErand1bin';           % <<< CHANGE THIS
AlgorithmHandle = @runAlgorithmTemplate;   % <<< CHANGE IF YOU USE ANOTHER FILE

% Number of independent runs per problem (competition suggestion: 25–31)
RunNumber = 2;

% Algorithm parameters (modify as needed for your method)
AlgorithmParams = struct();
AlgorithmParams.PopulationSize = 100;  % Example for population-based methods
AlgorithmParams.F  = 0.5;              % Example (DE mutation factor)
AlgorithmParams.Cr = 0.9;              % Example (DE crossover rate)
% Add any algorithm-specific fields you need, e.g.:
% AlgorithmParams.w  = 0.7;  % inertia (for PSO)
% AlgorithmParams.c1 = 1.5;
% AlgorithmParams.c2 = 1.5;

% Evaluation budgets at which error is reported
evalPoints    = [10000, 50000, 100000, 150000, 200000, ...
                 250000, 300000, 350000, 400000, 450000, 500000];
numEvalPoints = numel(evalPoints);

% Multi-target thresholds for FE-to-target + ERT
TargetThresholds = [1e-1, 1e-3, 1e-5, 1e-8];
numTargets       = numel(TargetThresholds);

% List of benchmark problem files
problemFiles = {
    'F1_Unimodal_Separable.mat'
    'F2_Unimodal_FullyCoupled.mat'
    'F3_IllConditioned_Separable.mat'
    'F4_IllConditioned_Coupled.mat'
    'F5_Chain_Deceptive.mat'
    'F6_SuperLinear.mat'
    'F7_PartialSeparable.mat'
    'F8_Sparse50.mat'
    'F9_Dense90.mat'
    'F10_MixedConditioning.mat'
    'F11_Multimodal_Symmetric_Sep.mat'
    'F12_Multimodal_Symmetric_Coupled.mat'
    'F13_Multimodal_Asymmetric_Sep.mat'
    'F14_Multimodal_Asymmetric_Coupled.mat'
    'F15_HighlyMultimodal_IllConditioned.mat'
    'F16_Deceptive.mat'
    'F17_ThreeComponents_Overlapping.mat'
    'F18_ThreeComponents_MixedCond.mat'
    'F19_FiveComponents_HighAsym.mat'
    'F20_MixedBasin.mat'
    'F21_PartialSep_MultiComp.mat'
    'F22_ExtremeHybrid.mat'
    'F23_Noisy.mat'
    'F24_Dynamic.mat'
};

% Which problems to test (default: all 24)
problemsToTest = 1:24;
% Example: problemsToTest = [1:6 11:16];

% Pre-allocate result struct
Results(24) = struct();  % we index by F1..F24

%% ==================== HEADER ====================

fprintf('\n====================================================\n');
fprintf('  GNBG-III COMPETITION HARNESS\n');
fprintf('====================================================\n');
fprintf('Algorithm: %s\n', AlgorithmName);
fprintf('Runs per problem: %d\n', RunNumber);
fprintf('Evaluation budget per run: %d\n', evalPoints(end));
fprintf('Evaluation points: ');
fprintf('%dK ', evalPoints/1000);
fprintf('\nTargets for FE-to-target/ERT: ');
for t = 1:numTargets
    fprintf('%.0e ', TargetThresholds(t));
end
fprintf('\n====================================================\n\n');

totalStartTime = tic;

%% ==================== MAIN TESTING LOOP ====================

for p = 1:numel(problemsToTest)
    probIdx = problemsToTest(p);
    
    fprintf('Testing F%d: %s\n', probIdx, strrep(problemFiles{probIdx}, '.mat', ''));
    fprintf('  Progress: ');
    
    % Load once to get dimension and MaxEvals
    clear GNBG;
    load(fullfile(benchmarkDir, problemFiles{probIdx}));
    MaxEvals = GNBG.MaxEvals;          % competition standard: 5e5
    
    % Pre-allocate per-problem containers
    ErrorAtPoints      = NaN(numEvalPoints, RunNumber);
    ConvBhv            = NaN(RunNumber, MaxEvals);   % |f_best - f*| per FE
    AcceptancePoints   = NaN(1, RunNumber);          % FE where |f-f*|<=1e-8
    FETargets          = NaN(RunNumber, numTargets); % FE-to-target per threshold
    
    % Optional containers for algorithm-specific diagnostics
    DiversityHistory   = NaN(RunNumber, 50); % if provided by algorithm
    ImprovementCounts  = NaN(RunNumber, 1);
    StagnationPeriods  = NaN(RunNumber, 1);
    
    problemStartTime = tic;
    
    for run = 1:RunNumber
        
        % Simple progress indicator: dots and run number at multiples of 5
        if mod(run, 5) == 0
            fprintf('%d ', run);
        else
            fprintf('.');
        end
        
        %------------------------------------------------------------------
        % Load fresh copy of GNBG problem
        %------------------------------------------------------------------
        clear GNBG;
        load(fullfile(benchmarkDir, problemFiles{probIdx}));
        
        % Recommended deterministic seeding policy per (problem, run):
        rng(100000 + 1000*probIdx + run);
        
        %------------------------------------------------------------------
        % Call participant algorithm
        %------------------------------------------------------------------
        try
            [BestHistory, BestValue, BestPosition, GNBG, AcceptanceReachPoint, Extra] = ...
                AlgorithmHandle(GNBG, AlgorithmParams);
        catch
            % If Extra is not returned, fall back to 5-output variant
            [BestHistory, BestValue, BestPosition, GNBG, AcceptanceReachPoint] = ...
                AlgorithmHandle(GNBG, AlgorithmParams);
            Extra = struct();
        end
        
        %------------------------------------------------------------------
        % Normalise/validate BestHistory
        %   - Should be 1 x MaxEvals (best-so-far function value per FE)
        %------------------------------------------------------------------
        BestHistory = BestHistory(:)';  % ensure row vector
        
        if numel(BestHistory) < MaxEvals
            % Pad with final best value if shorter than MaxEvals
            BestHistory(numel(BestHistory)+1:MaxEvals) = BestHistory(end);
        elseif numel(BestHistory) > MaxEvals
            % Truncate if longer than MaxEvals
            BestHistory = BestHistory(1:MaxEvals);
        end
        
        % Enforce monotone non-increasing best-so-far behaviour
        for fe = 2:MaxEvals
            if BestHistory(fe) > BestHistory(fe-1)
                BestHistory(fe) = BestHistory(fe-1);
            end
        end
        
        %------------------------------------------------------------------
        % Compute error curve and FE-to-target metrics
        %------------------------------------------------------------------
        errorCurve = abs(BestHistory - GNBG.OptimumValue);
        ConvBhv(run, :) = errorCurve;
        
        % Error at evaluation points
        for i = 1:numEvalPoints
            idx = evalPoints(i);
            if idx <= MaxEvals
                ErrorAtPoints(i, run) = errorCurve(idx);
            else
                ErrorAtPoints(i, run) = errorCurve(end);
            end
        end
        
        % AcceptanceReachPoint: FE where |f - f*| <= 1e-8 (from algorithm)
        AcceptancePoints(run) = AcceptanceReachPoint;
        
        % Multi-target FE-to-target
        for t = 1:numTargets
            thr    = TargetThresholds(t);
            hitIdx = find(errorCurve <= thr, 1, 'first');
            if ~isempty(hitIdx)
                FETargets(run, t) = hitIdx;
            else
                FETargets(run, t) = NaN;  % never reached
            end
        end
        
        %------------------------------------------------------------------
        % Optional diagnostics from Extra (if algorithm provides them)
        %------------------------------------------------------------------
        if isfield(Extra, 'DiversityHistory')
            % Expect a vector; resample / crop to 50 points if needed
            dh = Extra.DiversityHistory(:)';
            if numel(dh) >= 50
                DiversityHistory(run, :) = dh(1:50);
            else
                DiversityHistory(run, 1:numel(dh)) = dh;
            end
        end
        
        if isfield(Extra, 'ImprovementCount')
            ImprovementCounts(run) = Extra.ImprovementCount;
        end
        
        if isfield(Extra, 'StagnationPeriods')
            StagnationPeriods(run) = Extra.StagnationPeriods;
        end
    end  % runs loop
    
    problemElapsedTime = toc(problemStartTime);
    fprintf(' Done! (%.1f sec)\n', problemElapsedTime);
    
    %----------------------------------------------------------------------
    % Aggregate per-problem statistics
    %----------------------------------------------------------------------
    nonInfIdx = isfinite(AcceptancePoints);
    nonInfVal = AcceptancePoints(nonInfIdx);
    
    % Store raw data
    Results(probIdx).AlgorithmName      = AlgorithmName;
    Results(probIdx).ProblemName       = problemFiles{probIdx};
    Results(probIdx).EvalPoints        = evalPoints;
    Results(probIdx).ErrorAtPoints     = ErrorAtPoints;
    Results(probIdx).ConvBhv           = ConvBhv;
    Results(probIdx).AcceptancePoints  = AcceptancePoints;
    Results(probIdx).Targets           = TargetThresholds;
    Results(probIdx).FETargets         = FETargets;
    Results(probIdx).DiversityHistory  = DiversityHistory;
    Results(probIdx).ImprovementCounts = ImprovementCounts;
    Results(probIdx).StagnationPeriods = StagnationPeriods;
    
    % Per-evaluation-point statistics
    Results(probIdx).MeanErrors   = mean(ErrorAtPoints, 2);
    Results(probIdx).StdErrors    = std(ErrorAtPoints, 0, 2);
    Results(probIdx).MedianErrors = median(ErrorAtPoints, 2);
    
    % Key budgets (assuming evalPoints(3)=100k, (6)=250k, end=500k)
    Results(probIdx).MeanError100k   = mean(ErrorAtPoints(3, :));
    Results(probIdx).MeanError250k   = mean(ErrorAtPoints(6, :));
    Results(probIdx).MeanError500k   = mean(ErrorAtPoints(end, :));
    Results(probIdx).MedianError500k = median(ErrorAtPoints(end, :));
    Results(probIdx).StdError500k    = std(ErrorAtPoints(end, :));
    Results(probIdx).MinError500k    = min(ErrorAtPoints(end, :));
    Results(probIdx).MaxError500k    = max(ErrorAtPoints(end, :));
    
    % Success rate for 1e-8 (based on AcceptancePoints)
    Results(probIdx).SuccessRate = 100 * sum(nonInfIdx) / RunNumber;
    
    if ~isempty(nonInfVal)
        Results(probIdx).MeanFEtoThreshold = mean(nonInfVal);
        Results(probIdx).StdFEtoThreshold  = std(nonInfVal);
    else
        Results(probIdx).MeanFEtoThreshold = Inf;
        Results(probIdx).StdFEtoThreshold  = NaN;
    end
    
    % Multi-target success rates and ERT
    TargetSuccessRate = zeros(1, numTargets);
    ERT              = zeros(1, numTargets);
    for t = 1:numTargets
        fe          = FETargets(:, t);
        successMask = ~isnan(fe);
        TargetSuccessRate(t) = 100 * sum(successMask) / RunNumber;
        
        if any(successMask)
            feFilled = fe;
            feFilled(~successMask) = MaxEvals;      % penalise failures by MaxEvals
            ERT(t) = sum(feFilled) / sum(successMask);
        else
            ERT(t) = Inf;
        end
    end
    Results(probIdx).TargetSuccessRate = TargetSuccessRate;
    Results(probIdx).ERT               = ERT;
    
    % Quick console summary for the strictest target (1e-8)
    fprintf('  Summary: Err@500K = %.2e (±%.2e), SR(1e-8)=%.1f%%, ', ...
        Results(probIdx).MeanError500k, Results(probIdx).StdError500k, Results(probIdx).SuccessRate);
    fprintf('ERT(1e-8) = ');
    if isfinite(ERT(end))
        fprintf('%.0f FEs\n', ERT(end));
    else
        fprintf('Inf\n');
    end
    fprintf('\n');
end  % problems loop

totalElapsedTime = toc(totalStartTime);
fprintf('Total computation time: %.1f minutes\n', totalElapsedTime/60);

%% ==================== SAVE RESULTS (.MAT) ====================

matFileName = sprintf('GNBG_III_DetailedResults_%s.mat', AlgorithmName);
save(matFileName, 'Results', 'AlgorithmParams', 'evalPoints', 'TargetThresholds', 'AlgorithmName');
fprintf('Detailed .MAT results saved to: %s\n', matFileName);

%% ==================== EXPORT RESULTS TO CSV ====================

csvFileName = sprintf('GNBG_III_Detailed_Results_%s.csv', AlgorithmName);
fprintf('\nExporting detailed per-run results to CSV: %s\n', csvFileName);

try
    csvData = [];
    
    % Header row
    header = {'Algorithm', 'Problem', 'Run'};
    for i = 1:numEvalPoints
        header{end+1} = sprintf('Error_%dK', evalPoints(i)/1000);
    end
    header{end+1} = 'Acceptance_FE_1e-8';
    header{end+1} = 'Success_1e-8';
    % Multi-target FE-to-target & success flags
    for t = 1:numTargets
        header{end+1} = sprintf('FE_to_%.0e', TargetThresholds(t));
        header{end+1} = sprintf('Success_%.0e', TargetThresholds(t));
    end
    
    csvData = [csvData; header];
    
    % Rows: per problem, per run
    for p = 1:numel(problemsToTest)
        probIdx = problemsToTest(p);
        for run = 1:RunNumber
            row = {AlgorithmName, sprintf('F%d', probIdx), sprintf('Run%d', run)};
            
            % Error at eval points
            for i = 1:numEvalPoints
                row{end+1} = Results(probIdx).ErrorAtPoints(i, run);
            end
            
            % Acceptance FE and success flag (1e-8)
            if isfinite(Results(probIdx).AcceptancePoints(run))
                row{end+1} = Results(probIdx).AcceptancePoints(run);
                row{end+1} = 1;
            else
                row{end+1} = NaN;
                row{end+1} = 0;
            end
            
            % Multi-target FE-to-target
            for t = 1:numTargets
                feVal = Results(probIdx).FETargets(run, t);
                if isfinite(feVal)
                    row{end+1} = feVal;
                    row{end+1} = 1;
                else
                    row{end+1} = NaN;
                    row{end+1} = 0;
                end
            end
            
            csvData = [csvData; row];
        end
    end
    
    % Write CSV
    fid = fopen(csvFileName, 'w');
    for i = 1:size(csvData, 1)
        for j = 1:size(csvData, 2)
            val = csvData{i,j};
            if ischar(val) || isstring(val)
                fprintf(fid, '%s', val);
            else
                fprintf(fid, '%.6e', val);
            end
            if j < size(csvData, 2)
                fprintf(fid, ',');
            end
        end
        fprintf(fid, '\n');
    end
    fclose(fid);
    
    fprintf('CSV export complete.\n');
catch ME
    fprintf('Warning: CSV export failed: %s\n', ME.message);
end

fprintf('\n====================================================\n');
fprintf('GNBG-III COMPETITION HARNESS FINISHED\n');
fprintf('====================================================\n');
